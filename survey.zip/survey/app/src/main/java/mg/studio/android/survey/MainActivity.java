package mg.studio.android.survey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    int nowPage;
    int questions[] = {
            R.layout.question_one,
            R.layout.question_two,
            R.layout.question_three,
            R.layout.question_four,
            R.layout.question_five,
            R.layout.question_six,
            R.layout.question_seven,
            R.layout.question_eight,
            R.layout.question_nine,
            R.layout.question_ten,
            R.layout.question_eleven,
            R.layout.question_twelve
    };

    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);
        intent = new Intent(this, Report.class);
    }

    public void goToSurvey(android.view.View V) {
        CheckBox cb_accept = findViewById(R.id.accept);
        if(!cb_accept.isChecked())
            return;
        setContentView(R.layout.question_one);
        nowPage = 0;
    }

    public void goToNextPage(android.view.View V) {
        recordChoice(nowPage);
        nowPage++;

        if(nowPage>=12)
            setContentView(R.layout.finish_survey);
        else
            setContentView(questions[nowPage]);
    }

    public void goToReport(android.view.View V) {
        startActivity(intent);
    }

    public void recordChoice(int question) {
        switch(question) {
            case 0:
                intent.putExtra("ans0", getRadioAnswer(R.id.rd_1));
                break;
            case 1:
                intent.putExtra("ans1", getRadioAnswer(R.id.rd_2));
                break;
            case 2:
                intent.putExtra("ans2", getRadioAnswer(R.id.rd_3));
                break;

            case 3:
                intent.putExtra("ans3", getCheckBoxAnswer(R.id.cb_4));
                break;
            case 4:
                intent.putExtra("ans4", getCheckBoxAnswer(R.id.cb_5));
                break;

            case 5:
                intent.putExtra("ans5", ((EditText)findViewById(R.id.editText))
                        .getText().toString());
                break;

            case 6:
                intent.putExtra("ans6", getRadioAnswer(R.id.rd_7));
                break;
            case 7:
                intent.putExtra("ans7", getRadioAnswer(R.id.rd_8));
                break;
            case 8:
                intent.putExtra("ans8", getRadioAnswer(R.id.rd_9));
                break;
            case 9:
                intent.putExtra("ans9", getRadioAnswer(R.id.rd_10));
                break;
            case 10:
                intent.putExtra("ans10", getRadioAnswer(R.id.rd_11));
                break;
            case 11:
                intent.putExtra("ans11", getRadioAnswer(R.id.rd_12));
                break;
        }
    }

    public String getRadioAnswer(int id) {
        RadioGroup radioGroup = (RadioGroup) findViewById(id);
        String ans =
                ((RadioButton)findViewById(radioGroup.getCheckedRadioButtonId()))
                        .getText().toString();
        return ans;
    }

    public String getCheckBoxAnswer(int id) {
        String ans = new String();
        LinearLayout layout = findViewById(id);
        int count = layout.getChildCount();
        for(int i=0; i<count; i++) {
            CheckBox cb = (CheckBox) layout.getChildAt(i);
            if(cb.isChecked()) {
                if(ans.length() != 0)
                    ans += "\n";
                ans += cb.getText().toString();
            }
        }
        return ans;
    }
}
