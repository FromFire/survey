package mg.studio.android.survey;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {
    int nowPage;
    int questions[] = {
            R.layout.question_one,
            R.layout.question_two,
            R.layout.question_three,
            R.layout.question_four,
            R.layout.question_five,
            R.layout.question_six,
            R.layout.question_seven,
            R.layout.question_eight,
            R.layout.question_nine,
            R.layout.question_ten,
            R.layout.question_eleven,
            R.layout.question_twelve
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);
    }

    public void goToSurvey(android.view.View V) {
        CheckBox cb_accept = findViewById(R.id.accept);
        if(!cb_accept.isChecked())
            return;
        setContentView(R.layout.question_one);
        nowPage = 0;
    }

    public void goToNextPage(android.view.View V) {
        nowPage++;
        if(nowPage>=12)
            setContentView(R.layout.finish_survey);
        else
            setContentView(questions[nowPage]);
    }

    public void exit(android.view.View V) {
        System.exit(0);
    }

}
