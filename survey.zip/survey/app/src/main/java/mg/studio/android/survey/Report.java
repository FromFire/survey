package mg.studio.android.survey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import static androidx.annotation.InspectableProperty.ValueType.GRAVITY;

public class Report extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        showReport();
    }

    protected void showReport() {
        Intent intent = getIntent();
        addItem("1 Which brand of phone will you choose if you are going to buy a new one?",
                intent.getStringExtra("ans0"));
        addItem("2 How much does your phone cost?",
                intent.getStringExtra("ans1"));
        addItem("3 What kind of phone are you using?",
                intent.getStringExtra("ans2"));
        addItem("4 What functions does your phone have now?",
                intent.getStringExtra("ans3"));
        addItem("5 What functions are the most often used?",
                intent.getStringExtra("ans4"));
        addItem("6 What functions do you expect your phone to have in the future?",
                intent.getStringExtra("ans5"));
        addItem("7 In which condition will you buy a new phone?",
                intent.getStringExtra("ans6"));
        addItem("8 Which brand of phone will you choose if you are going to buy a new one?",
                intent.getStringExtra("ans7"));
        addItem("9 What characteristic do you think is most important to evaluate a phone?",
                intent.getStringExtra("ans8"));
        addItem("10 How old are you?",
                intent.getStringExtra("ans9"));
        addItem("11 What's your gender?",
                intent.getStringExtra("ans10"));
        addItem("12 How much money do you earn per month?",
                intent.getStringExtra("ans11"));
    }

    protected void addItem(String question, String answer) {
        LinearLayout layout = findViewById(R.id.answer_area);

        TextView q = new TextView(this);
        LinearLayout.LayoutParams param =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        param.gravity = Gravity.CENTER_HORIZONTAL;
        param.bottomMargin = 10;
        q.setLayoutParams(param);
        q.setText(question);
        q.setTextSize(20);

        TextView a = new TextView(this);
        LinearLayout.LayoutParams param2 =
                new LinearLayout.LayoutParams(650,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        param2.gravity = Gravity.CENTER_HORIZONTAL;
        param2.bottomMargin = 60;
        a.setLayoutParams(param2);
        a.setText(answer);
        a.setTextSize(16);

        layout.addView(q);
        layout.addView(a);
    }


    public void exit() {
        System.exit(0);
    }

}
