package mg.studio.android.survey;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;

public class Report extends AppCompatActivity {

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        showReport();
    }

    protected void showReport() {
        Intent intent = getIntent();
        addItem("1 Which brand of phone will you choose if you are going to buy a new one?",
                intent.getStringExtra("ans0"));
        addItem("2 How much does your phone cost?",
                intent.getStringExtra("ans1"));
        addItem("3 What kind of phone are you using?",
                intent.getStringExtra("ans2"));
        addItem("4 What functions does your phone have now?",
                intent.getStringExtra("ans3"));
        addItem("5 What functions are the most often used?",
                intent.getStringExtra("ans4"));
        addItem("6 What functions do you expect your phone to have in the future?",
                intent.getStringExtra("ans5"));
        addItem("7 In which condition will you buy a new phone?",
                intent.getStringExtra("ans6"));
        addItem("8 Which brand of phone will you choose if you are going to buy a new one?",
                intent.getStringExtra("ans7"));
        addItem("9 What characteristic do you think is most important to evaluate a phone?",
                intent.getStringExtra("ans8"));
        addItem("10 How old are you?",
                intent.getStringExtra("ans9"));
        addItem("11 What's your gender?",
                intent.getStringExtra("ans10"));
        addItem("12 How much money do you earn per month?",
                intent.getStringExtra("ans11"));
    }

    protected void addItem(String question, String answer) {
        LinearLayout layout = findViewById(R.id.answer_area);

        TextView q = new TextView(this);
        LinearLayout.LayoutParams param =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        param.gravity = Gravity.CENTER_HORIZONTAL;
        param.bottomMargin = 10;
        q.setLayoutParams(param);
        q.setText(question);
        q.setTextSize(20);

        TextView a = new TextView(this);
        LinearLayout.LayoutParams param2 =
                new LinearLayout.LayoutParams(650,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        param2.gravity = Gravity.CENTER_HORIZONTAL;
        param2.bottomMargin = 60;
        a.setLayoutParams(param2);
        a.setText(answer);
        a.setTextSize(16);

        layout.addView(q);
        layout.addView(a);
    }


    public void exit(android.view.View V) {
        System.exit(0);
    }

    public void storeInApp(android.view.View V) {
        Intent intent = getIntent();
        try {
            JSONObject jobj = new JSONObject();
            for(int i=0; i<12; i++)
                jobj.put("answer" + Integer.toString(i),
                        intent.getStringExtra("ans" + Integer.toString(i)));
            String output = jobj.toString();

            ContextWrapper c = new ContextWrapper(this);
            File file = new File(c.getFilesDir(),"info.json");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(output.getBytes());
            fos.flush();
            fos.close();

            Toast.makeText(Report.this, "Store in app: success", Toast.LENGTH_LONG).show();

        } catch(JSONException e) {
            e.printStackTrace();
            Toast.makeText(Report.this, "failed: JSON Error", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(Report.this, "failed: File Error", Toast.LENGTH_LONG).show();
        }
    }

    public void storeInSDCard(android.view.View V) {
        Intent intent = getIntent();
        askForPermission();
        if(Environment.getExternalStorageState() == Environment.MEDIA_UNKNOWN) {
            Toast.makeText(Report.this, "You don't have a SD card!", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            JSONObject jobj = new JSONObject();
            for(int i=0; i<12; i++)
                jobj.put("answer" + Integer.toString(i),
                        intent.getStringExtra("ans" + Integer.toString(i)));
            String output = jobj.toString();

            File f = Environment.getExternalStorageDirectory();
            File file = new File(f, "info.json");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(output.getBytes());
            fos.flush();
            fos.close();

            Toast.makeText(Report.this, "Store inside SD card: success", Toast.LENGTH_LONG).show();

        } catch(JSONException e) {
            e.printStackTrace();
            Toast.makeText(Report.this, "failed: JSON Error", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(Report.this, "failed: File Error", Toast.LENGTH_LONG).show();
        }
    }

    public void askForPermission() {
        int permission = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE);
        }
    }


}
